
import CommentBox from './CommentBox.js';


          ReactDOM.render(
          <CommentBox  />,
          document.getElementById('content')
		);
