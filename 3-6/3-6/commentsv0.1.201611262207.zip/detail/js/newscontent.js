import '../../asset/style/style1.css';
import '../../asset/style/style1.debug.css';
import '../../asset/style/style.news.v1.css';
import NewsContent from '../js/content.js';
ReactDOM.render(<NewsContent />,document.getElementById('content'));
