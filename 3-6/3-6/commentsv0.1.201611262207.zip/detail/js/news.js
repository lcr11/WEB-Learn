import  '../../asset/style/style1.css';
import  '../../asset/style/style1.debug.css';
import  NewsList from './newslist.js';
    ReactDOM.render(
          <NewsList />,
          document.getElementById('content')
		);
