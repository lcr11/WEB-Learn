import '../asset/style/global.css';
//import '../js/template.js';
//import qqlogo from  '../asset/js';
//console.log(qqlogo);
//$('body').html('<img src="'+qqlogo+'">');

import './detail.js';
